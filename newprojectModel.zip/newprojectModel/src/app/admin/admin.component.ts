import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserInfoService } from "../user-info.service"
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router:Router, private userInfoService : UserInfoService, private httpClient : HttpClient) { }


  counteries : any = [];

  // @Output() save = new EventEmitter<{}>();

  ngOnInit(): void {
    
    this.httpClient.get("http://localhost:3000/admin").subscribe((data : [])=>{      
    
      this.counteries = data;
  })
}

getView(form)
  {
    console.log(form);
    //this.userinfoService.add(this.user);
    this.router.navigate(['/view']);
  }

  getUpdate(form)
  {
    console.log(form);
    //this.userinfoService.add(this.user);
    this.router.navigate(['/update']);
  }

  getDelete(form)
  {
    console.log(form);
    //this.userinfoService.add(this.user);
    this.router.navigate(['/delete']);
  }


  saveUser(form : NgForm)
    {
        this.userInfoService.add(form.value);
      // this.save.next(form.value)
    }

  addtodata(form : NgForm)
    { 
      
      return this.userInfoService.adddata(form.value).subscribe(()=>{
        console.log("test_is_working"),
         this.router.navigate(['/admin']);
      })
    }
    

}
