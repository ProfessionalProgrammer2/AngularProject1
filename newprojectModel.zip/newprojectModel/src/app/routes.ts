import { Routes } from "@angular/router";
import { AdminComponent } from "./admin/admin.component";
import { LoginComponent } from "./login/login.component";
import { UserComponent } from "./user/user.component";
import { HomeComponent } from './home/home.component';
import { ViewComponent } from './view/view.component';
import { UpdateComponent } from './update/update.component';
import { DeleteComponent } from './delete/delete.component';


const AppRoutes : Routes = [
  { path : "login", component : LoginComponent },
  { path : "admin", component : AdminComponent },
  { path : "user", component : UserComponent },
  { path : 'home', component : HomeComponent},
    { path : 'view', component : ViewComponent},
    { path : 'update', component : UpdateComponent},
    { path : 'delete', component : DeleteComponent},
  { path : "", redirectTo : "/login", pathMatch: 'full' }
]

export {
  AppRoutes
}
