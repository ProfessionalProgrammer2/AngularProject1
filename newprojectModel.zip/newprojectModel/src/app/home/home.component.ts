import { Component, OnInit } from '@angular/core';
//import { AppRoutingModule } from '../app-routing.module';
import { Router } from "@angular/router";
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  customer : any[] = [];
  constructor(private router:Router) { }

  ngOnInit(): void {
    //this.customer = this.
  }

  getView(form)
  {
    console.log(form);
    //this.userinfoService.add(this.user);
    this.router.navigate(['/view']);
  }

  getUpdate(form)
  {
    console.log(form);
    //this.userinfoService.add(this.user);
    this.router.navigate(['/update']);
  }

  getDelete(form)
  {
    console.log(form);
    //this.userinfoService.add(this.user);
    this.router.navigate(['/delete']);
  }
}
