import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserInfoService {

  list : any= [];
  clients : any= [];

  listObserve = new Subject<[]>();

  constructor(private router : Router, private httpClient : HttpClient) 
  {
    this.httpClient.get("http://localhost:3000/admin").subscribe((data:[])=>{
      this.clients = data;
      });
  }

  login(user)
  {
    let checkifuserfound : boolean = false; 
    let checkifuseradmin : boolean = false; 
    for(let i = 0; i < this.clients.length; i ++)
    {
      if (user.username == this.clients[i].username && user.password == this.clients[i].password)
      {
        checkifuserfound = true;
        
        if (user.username == "admin")
        {
          checkifuseradmin = true;
        }
      }
    }
    if(checkifuserfound == true)
    {
      if(checkifuseradmin == false)
      {
        this.router.navigate(["/user"])
      }
      else
      {
        this.router.navigate(["/admin"])
      }
    }
    else
    {
      this.router.navigate(["/login"])
    }
  }

  add(user)
    {
      this.list.push(user);
      this.listObserve.next(this.list);
      // console.log(this.list);
    }

  getList()
    {
        return this.listObserve;
    }

  calculate(a : number,b : number)
    {
      return a + b;
    }

    adddata(user)
  { 
    return this.httpClient.post("http://localhost:3000/admin", user);
  }

  delete_data(user)
  { 
    return this.httpClient.delete("http://localhost:3000/admin", user);
     
  }

  

}