import { Component, OnInit } from '@angular/core';
//import { PolicyService } from '../policy.service';
import { NgForm } from '@angular/forms';
import { UserInfoService } from '../user-info.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.scss']
})
export class DeleteComponent implements OnInit {

  //policyId : number = 0;
  user: { username: string, password: string, id: string } = {
    username: "",
    password: "",
    id: "",
  }
  constructor(private userinfoService : UserInfoService) { }

  ngOnInit(): void {
  }


  addtodata(form : NgForm)
  { 
    return this.userinfoService.adddata(form.value).subscribe(()=>{
      console.log("test_is_working for add")
    })
  }

  

  delete_from_data(form : NgForm)
  { 
    return this.userinfoService.delete_data(form.value).subscribe(()=>{
      console.log("test_is_working for delete")
    })
  }
 /* public deletePolicy(policyId){
    this.policyService.deletePolicy(policyId).subscribe((ret)=>{
          console.log("Policy deleted: ", ret);
    })
}
*/
  
} 


