import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormsModule, NgForm } from "@angular/forms";
import { HttpClient } from '@angular/common/http';
import { UserInfoService } from "../user-info.service"

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router : Router, private httpClient : HttpClient, private userinfo : UserInfoService) { }

  countries : any = [];

  ngOnInit(): void {
    this.httpClient.get("http://localhost:3000/admin").subscribe((data:[])=>{
    this.countries = data;
    });
  }

  fetch(form : NgForm)
  {
    return this.userinfo.login(form.value);
  }

}
