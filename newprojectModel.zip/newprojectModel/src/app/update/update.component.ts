import { Component, OnInit } from '@angular/core';
//import { Router, ActivatedRoute } from '@angular/router';
//import { ApiService } from '../api.service';
//import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { UserInfoService } from '../user-info.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.scss']
})
export class UpdateComponent implements OnInit {
 // policies: any[] = [];
 // policyId : any;

  //constructor( private route: ActivatedRoute, private api : ApiService, private formBuilder: FormBuilder) { }
  employees : any = [];
  searchText: any;
  user: { username: string, password: string, id: string } = {
    username: "",
    password: "",
    id: "",
  }

  constructor( private userinfoService : UserInfoService) { }
  ngOnInit(): void {
   



  }

  addtodata(form : NgForm)
  { 
    return this.userinfoService.adddata(form.value).subscribe(()=>{
      console.log("test_is_working")
    })
  }

 // getBook(id) {
   /* this.api.getBook(id).subscribe(data => {
      this.id = data._id;
      this.bookForm.setValue({
        isbn: data.isbn,
        title: data.title,
        description: data.description,
        author: data.author,
        publisher: data.publisher,
        published_year: data.published_year
      });
    });*/
  //}

 // onFormSubmit(form:NgForm) {
    /*this.api.updateBook(this.id, form)
      .subscribe(res => {
          let id = res['_id'];
         // this.router.navigate(['/view']);
        }, (err) => {
          console.log(err);
        }
      );*/
 // }

 // bookDetails() {
    //this.router.navigate(['/view']);
  //}
  /*public createPolicy(policy){
    this.policyService.createPolicy(policy).subscribe((ret)=>{
          console.log("Policy created: ", ret);
    });
}*/

/*public updatePolicy(policy: {id: number, amount: number, clientId: number, userId: number, description: string}){
  let newPolicy:{id: number, amount: number, clientId: number, userId: number, description: string} = {policy.id, 0, 0, 0};
  this.policyService.updatePolicy(policyId).subscribe((ret)=>{
        console.log("Policy updated: ", ret);
  });
}*/
}
