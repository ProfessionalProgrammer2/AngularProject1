import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//import { NgForm } from '@angular/forms';


import { UserInfoService } from "../user-info.service"
import { Router } from "@angular/router";
//import { LibraryService } from '../library.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit {

  books = [];
  counteries : any = [];
 
  constructor(private router :Router, private userInfoService : UserInfoService, private httpClient : HttpClient) { }

  ngOnInit(): void {

    this.httpClient.get("http://localhost:3000/admin").subscribe((data : [])=>{      
    
      this.counteries = data;
  })
}

  getView()
  {
    console.log();
    //this.userinfoService.add(this.user);
    this.router.navigate(['/view']);
  }

  getUpdate()
  {
    console.log();
    //this.userinfoService.add(this.user);
    this.router.navigate(['/update']);
  }

  getDelete()
  {
    console.log();
    //this.userinfoService.add(this.user);
    this.router.navigate(['/delete']);
  }

}

